//var desip = "47.99.195.202"
var desip = "192.168.100.136"