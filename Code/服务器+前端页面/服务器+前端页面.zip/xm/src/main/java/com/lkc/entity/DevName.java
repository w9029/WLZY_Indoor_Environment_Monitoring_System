package com.lkc.entity;

//板子获取阈值用
public class DevName {
    private String name;

    public String getName() {
        return name;
    }
}
