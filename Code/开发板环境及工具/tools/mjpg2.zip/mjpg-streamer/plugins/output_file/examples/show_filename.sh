#!/bin/bash

################################################################################
# This example just displays the filename of the just created file
#
#
################################################################################

# the last created filename is passed by two different variables
echo "Just stored the file ${MJPG_FILE}, which equals ${1}"
